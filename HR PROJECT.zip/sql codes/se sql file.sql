use jobms;
select * from consolidated_search_se;

-- total no. of jobs?
select count(*)  from consolidated_search_se;

-- total no. of companies providing jobs?
select count(distinct company)  from consolidated_search_se;

--  total jobs for various domains?
select count(distinct `job Title`)from consolidated_search_se;




-- distribution of jobs across various software engineering  fields?
select count(`job title`) as total , `job title` from  consolidated_search_se
group by `job title` order by total desc;

-- company providing highest number of jobs?
select count(`company`) as openings, `company` from consolidated_search_se
group by `company` order by openings desc ;

-- domain has the highest number of jobs?
select count(`job title`) as total_jobs ,`job title` from consolidated_search_se
group by `job title` order by total_jobs desc ;
 
-- minimum required qualification for job roles?
select `qualification`  from consolidated_search_se 
group by `qualification`;
 
select `search term` as scv from consolidated_search_se
group by `search term`;

-- companies with highest number of Job Titles with FULL STACK DEVELOPER :
select count(`search term`) as num , `search term` from consolidated_search_se where `Search term` = 'Full Stack Developer'
group by `search term` order by num desc;

-- companies with highest number of Job Titles with  Front End Developer  : 
select count(`search term`)   as num , `search term` from consolidated_search_se where `Search term` =  'Front End Developer'
group by `search term` order by num desc;  


-- companies with highest number of Job Titles with Back End Developer :
select count(`search term`) as num ,`search term` from consolidated_search_se where `search term` = 'Back End Developer'
group by `search term` order by num desc ;


-- companies with highest number of Job Titles with Software Engineer:
select count(`search term`) as num ,`search term` from consolidated_search_se where `search term` = 'Software Engineer'
group by `search term` order by num desc ;

-- companies with highest number of Job Titles with Analyst Programmer:
select count(`search term`) as num ,`search term` from consolidated_search_se where `search term` = 'Analyst Programmer'
group by `search term` order by num desc ;

 



