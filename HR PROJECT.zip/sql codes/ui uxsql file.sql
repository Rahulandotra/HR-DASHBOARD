use jobms;
select * from consolidated_search_uiux;

-- total no. of jobs?
select count(*)  from consolidated_search_uiux;

-- total no. of companies providing jobs?
select count( `Company`) ,`Company` from consolidated_search_uiux
group by `Company`  order by count(`Company`) desc;
--  total jobs for various domains?
select count( `job Title`) ,`job title` from consolidated_search_uiux
group by `job title`  order by count(`job title`) desc;
select count( `industry`) ,`industry` from consolidated_search_uiux
group by `industry`  order by count(`industry`) desc;

-- distribution of jobs across various software engineering  fields?
select count(`job title`) as total , `job title` from  consolidated_search_uiux
group by `job title` order by total desc;

-- company providing highest number of jobs?
select count(`company`) as openings, `company` from consolidated_search_uiux
group by `company` order by openings desc ;

-- domain has the highest number of jobs?
select count(`job title`) as total_jobs ,`job title` from consolidated_search_uiux
group by `job title` order by total_jobs desc ;
 
-- minimum required qualification for job roles?
select `qualification`  from consolidated_search_uiux
group by `qualification`;
 
select `search term` as scv from consolidated_search_uiux
group by `search term`;

-- companies with highest number of Job Titles with UI UX DESIGNER :
select count(`search term`) as num , `search term` from consolidated_search_uiux where `Search term` = 'UI UX Designer'
group by `search term` order by num desc;

-- companies with highest number of Job Titles with  Front Ux Researcher  : 
select count(`search term`) as num , `search term` from consolidated_search_uiux where `Search term` =  'UX Researcher'
group by `search term` order by num desc;  


-- companies with highest number of Job Titles with Service Designer :
select count(`search term`) as num ,`search term` from consolidated_search_uiux where `search term` = 'Service Designer'
group by `search term` order by num desc ;


-- companies with highest number of Job Titles with Software Engineer:
select count(`search term`) as num ,`search term` from consolidated_search_uiux where `search term` = 'UX Consultant'
group by `search term` order by num desc ;

select count(distinct `job type`) from consolidated_search_uiux;
select count(

 

