use jobms ;

show tables ;
select * from consolidated_search_ds;

-- TOTAL NO. OF jobs :
select count(*) from consolidated_search_ds;

-- TOTAL COMPANIES :
select count(distinct company) from consolidated_search_ds;

-- TOTAL NO. OF INDUSTRIES:
select count(distinct industry) from consolidated_search_ds;

-- total career levl 
select count(`career level`) , `career level` from  consolidated_search_ds
group by  `career level`;

 -- TOTAL ANALYTICS FIELD:
 select count(`search term`), `search term` from consolidated_search_ds 
 group by `search term`;
 
 select count(distinct `search term`) from consolidated_search_ds ;
 
 -- total job types :
 select count(distinct `job type`) as job, `job type` from consolidated_search_ds ;
 
 
 -- companies with highest number of Job Titles with DATA SCIENTIST:
 select count(`company`),`company`  from  consolidated_search_ds   where `search term`= 'Data Scientist' 
 group by `company` order by count(`company`) desc;
 
  -- companies with highest number of Job Titles with DATA ANALYST:
 select count(`company`),`company`  from  consolidated_search_ds   where `search term`= 'Data Analyst' 
 group by `company` order by count(`company`) desc;
 
  -- companies with highest number of Job Titles with DATA ENGINEER:
 select count(`company`),`company`  from  consolidated_search_ds   where `search term`= 'Data Engineer' 
 group by `company` order by count(`company`) desc ;
 
  -- companies with highest number of Job Titles with MACHINE LEARNING ENGINEER:
 select count(`company`),`company`  from  consolidated_search_ds   where `search term`= 'Machine Learning Engineer' 
 group by `company` order by count(`company`) desc ;
 
  -- companies with highest number of Job Titles with BUSINESS INTELLIGENCE:
 select count(`company`),`company`  from  consolidated_search_ds   where `search term`= 'Business Intelligence' 
 group by `company` order by count(`company`) desc ; 
 
 -- domain with highest number of jobs:
 select count(*), `industry` from consolidated_search_ds where `search term`= 'Data Analyst'
 group by `industry` order by count(*) desc ;
 -- domain with heighest no. of jobs?
 select count(`industry`) abs , `industry` from consolidated_search_ds
 group by `industry` order by abs desc;
  select count(*),`company`, `career level` ,`industry`,`search term` from consolidated_search_ds where `career level`='Senior' 
  group by `search term` order by count(*) desc;
  
  select count(*),`company`, `career level` ,`industry` from consolidated_search_ds where `career level`='Senior' 
  group by `company` order by count(*) desc;
 

 select count(`industry`),`industry`  from  consolidated_search_ds   where `search term`= 'Data Analyst' 
 group by `industry` order by count(`industry`) desc;
 
  select count(`industry`),`industry`  from  consolidated_search_ds   where `search term`= 'Data Engineer' 
 group by `industry` order by count(`industry`) desc;

 
select count(`industry`),`industry`  from  consolidated_search_ds   where `search term`= 'Machine Learning Engineer' 
 group by `industry` order by count(`industry`) desc;
 
  select count(`industry`),`industry`  from  consolidated_search_ds   where `search term`= 'Business Intelligence' 
 group by `industry` order by count(`industry`) desc;
 
   select count(*),`industry`,`career level`,`search term`  from  consolidated_search_ds   where `search term`= 'Data Engineer' and `career level` ='Middle'
 group by `industry` order by count(`industry`) desc;
 
select count(*),`industry`,`career level`,`search term` from  consolidated_search_ds   where `search term`= 'Data Scientist' and `career level` ='Middle'; 
 
select count(*),`industry`,`career level`,`search term`  from  consolidated_search_ds   where `search term`= 'Data Analyst' and `career level` ='Middle';
 
select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Machine Learning Engineer' and `career level` ='Middle';
 
  select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Business Intelligence' and `career level` ='Middle';
 
select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Data Engineer' and `career level` ='Middle';


  select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Data Engineer' and `career level` ='Senior';
 
 
  select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Data Analyst' and `career level` ='Senior';
 
 
  select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Data Scientist' and `career level` ='Senior';
 
 
  select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Machine Learning Engineer' and `career level` ='Senior';
 
 
  select count(*),`industry` from  consolidated_search_ds   where `search term`= 'Business Intelligence' and `career level` ='Senior';
 
 select count(`industry`),`Industry`  from  consolidated_search_ds   
 group by `company` order by count(`company`) desc;
 